export class Clock {
    constructor(rootElement) {
        this.rootElement = rootElement;
        this.render();
    }

    render() {
        this.clockBtn = document.createElement('div');
        this.clockBtn.classList.add('clock-container');
        this.rootElement.appendChild(this.clockBtn);
        console.log(clockBtn);
  }
}


/*export function checkTime(){
    var today = new Date();
    var hr = today.getHours();
    var min = today.getMinutes();
    var sec = today.getSeconds();
    var hours = document.querySelector(".clock-container__hours");
    var minutes = document.querySelector(".clock-container__minutes");
    var seconds = document.querySelector(".clock-container__seconds");
    let timeBtn = document.querySelector("#clock");

    if(hr < 10){
      hr = "0" + hr;
    }
      if(min < 10){
      min = "0" + min;
    }
      if(sec < 10){
      sec = "0" + sec;
    }

    hours.textContent = hr + " : ";
    minutes.textContent = min + " ";

    timeBtn.addEventListener ( "click", function(){
        hours.textContent = hr + " : ";
        minutes.textContent = min;
        seconds.textContent = " : " + sec;
    })
  }

  setInterval(checkTime, 500);*/




