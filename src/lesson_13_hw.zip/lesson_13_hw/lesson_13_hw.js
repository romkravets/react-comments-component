import './lesson_13_hw.scss';

import { Clock } from './scripts/clock';

const clock = new Clock(document.querySelector('.clock-container'));









